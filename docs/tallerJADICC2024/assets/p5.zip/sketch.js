let colorBackground = 0;

// esta función se ejecuta al inicio para pre-cargar recursos como
// imágenes, sonidos, videos
function preload() {
}

// Inicializacion de la aplicacion
function setup() {
  createCanvas(400, 400);
}

// Esta funcion se ejecuta repetidamente (para animaciones)
function draw() {
  background(colorBackground);
  colorBackground = (colorBackground + 1) % 256;
}
