// Funciones de utilidad provisto por el docente

